# INKY CLIENT — Prototype 0.1

Interface de démonstration responsive pour le studio INKY TATTOO.

## Lancer en local

Ouvrir `index.html` dans un navigateur. Pour tester l'installation PWA et le service worker, servir le dossier via un serveur local ou un hébergement HTTPS.

## Contenu de cette première base

- Navigation : vue d'ensemble, clients, projets & séances, devis & paiements, après-soin, réglages.
- Interface responsive ordinateur / tablette / mobile.
- Fiches clients fictives ajoutées uniquement en mémoire pendant la session (pas de sauvegarde persistante).
- Manifest PWA et service worker de base.

## Important — prototype uniquement

Ne pas saisir de vraies données personnelles, de santé ou de consentement dans cette version. Elle n'inclut pas de base de données, d'authentification, de gestion des rôles, de stockage sécurisé, de signature électronique ni d'archivage PDF. Ces éléments doivent être conçus et sécurisés avant toute utilisation réelle en studio, avec une revue RGPD et sécurité adaptée.

## Choix produit déjà retenus

- Accès prévu sur tablette, mobile et ordinateur.
- Gestion interne manuelle, sans réservation en ligne.
- Profils envisagés : administrateur, artiste, assistant et accès client temporaire au formulaire.
- Consentements séparés : tatouage, traitement des données et autorisation photo facultative.
- Direction visuelle claire et éditoriale : blanc / blanc poudré, anthracite, touches discrètes de violet et rose.
